import tkinter as tk
from tkinter import ttk, font as tkFont
import threading
import time
import cv2
import numpy as np
import onnxruntime
import mss
# from PIL import Image, ImageTk # ImageTk 可能不再直接使用，但保留以防萬一
import ctypes
import ctypes.wintypes
import win32gui # 新增
import win32con # 新增
import win32api # 新增，用於 GetSystemMetrics
import sys
import os

# --- mouse_event & KeyPress Structures and Functions ---
# MOUSEEVENTF_MOVE = 0x0001 # 已在 win32con 中定義
# MOUSEEVENTF_ABSOLUTE = 0x8000 # 若要使用絕對座標時

def move_mouse_relative(dx, dy):
    global aimbot_speed_var
    speed_multiplier = aimbot_speed_var.get() if 'aimbot_speed_var' in globals() and aimbot_speed_var is not None else 1
    dx = int(dx * speed_multiplier)
    dy = int(dy * speed_multiplier)
    if dx == 0 and dy == 0: return
    ctypes.windll.user32.mouse_event(win32con.MOUSEEVENTF_MOVE, dx, dy, 0, 0)

VK_LBUTTON = 0x01
VK_RBUTTON = 0x02

def is_key_pressed(vk_code):
    return ctypes.windll.user32.GetAsyncKeyState(vk_code) & 0x8000 != 0
# --- End of mouse_event & KeyPress ---

# --- 設定 ---
def resource_path(relative_path):
    """取得資源檔案的絕對路徑，支援 PyInstaller 打包後的環境"""
    if hasattr(sys, '_MEIPASS'):
        return os.path.join(sys._MEIPASS, relative_path)
    return os.path.join(os.path.abspath("."), relative_path)

MODEL_FILE = resource_path("Rivals.onnx")
INITIAL_CONFIDENCE_THRESHOLD = 0.66
INITIAL_IOU_THRESHOLD = 0.26
INITIAL_SHOW_CONFIDENCE_TEXT = True
INITIAL_CONFIDENCE_FONT_SIZE = 20
INITIAL_DETECTION_INTERVAL = 0.0  # 設為0，代表最快速度(無間隔)
INITIAL_SHOW_HEAD_POINT = True
INITIAL_SHOW_BODY_POINT = True
INITIAL_X_OFFSET = 0
INITIAL_Y_OFFSET = 0
POINT_RADIUS = 3
INITIAL_FOV_SIZE = 666
INITIAL_FOV_THICKNESS = 2
OVERLAY_UPDATE_INTERVAL_MS = 10  # 設為10ms，約每秒100次，極速刷新

INITIAL_AIMBOT_ACTIVE = False
INITIAL_AIMBOT_TARGET_PART = "Head"
INITIAL_AIMBOT_KEY_LMB = True
INITIAL_AIMBOT_KEY_RMB = True

# --- 全域變數 ---
is_detection_running = threading.Event()
current_confidence_threshold = INITIAL_CONFIDENCE_THRESHOLD
current_iou_threshold = INITIAL_IOU_THRESHOLD
current_detection_interval = INITIAL_DETECTION_INTERVAL
show_confidence_text = None
confidence_font_size = None
show_head_point = None
show_body_point = None
current_x_offset = None
current_y_offset = None
current_fov_size = None
current_fov_thickness = None

aimbot_active_var = None
aimbot_target_part_var = None
aimbot_key_lmb_var = None
aimbot_key_rmb_var = None

latest_detections = []
screen_width, screen_height = 0, 0
root, overlay_window, overlay_canvas = None, None, None
detector_instance = None
default_font = None

# 新增：推論設備選擇
inference_device_var = None

class RivalDetectorYOLO:
    def __init__(self, model_path, device='GPU'):
        if device == 'GPU':
            # 僅使用 DirectML provider，出錯直接拋出，不退回 CPU
            self.session = onnxruntime.InferenceSession(model_path, providers=['DirectMLExecutionProvider'])
            print("已強制使用 DirectML (顯卡) 作為推論後端。若模型不支援將直接報錯。")
        else:
            self.session = onnxruntime.InferenceSession(model_path, providers=['CPUExecutionProvider'])
            print("已使用 CPU 作為推論後端。")
        model_inputs = self.session.get_inputs()
        self.input_name = model_inputs[0].name
        self.input_shape = model_inputs[0].shape
        self.input_height = self.input_shape[2]
        self.input_width = self.input_shape[3]
        model_outputs = self.session.get_outputs()
        self.output_names = [output.name for output in model_outputs]
        self.class_names = ["character"]
        print(f"偵測器初始化完成，輸入: {self.input_shape}, 輸出: {self.output_names}")

    def _preprocess(self, image_bgr):
        original_height, original_width = image_bgr.shape[:2]
        if original_width == 0 or original_height == 0:
            return None, 0, (0,0), 0, 0
        ratio = min(self.input_width / original_width, self.input_height / original_height)
        new_unpad_w = int(round(original_width * ratio))
        new_unpad_h = int(round(original_height * ratio))
        dw = (self.input_width - new_unpad_w) / 2
        dh = (self.input_height - new_unpad_h) / 2
        if (original_width, original_height) != (new_unpad_w, new_unpad_h):
            resized_image = cv2.resize(image_bgr, (new_unpad_w, new_unpad_h), interpolation=cv2.INTER_LINEAR)
        else:
            resized_image = image_bgr
        top, bottom = int(round(dh - 0.1)), int(round(dh + 0.1))
        left, right = int(round(dw - 0.1)), int(round(dw + 0.1))
        padded_image = cv2.copyMakeBorder(resized_image, top, bottom, left, right, cv2.BORDER_CONSTANT, value=(114, 114, 114))
        rgb_image = cv2.cvtColor(padded_image, cv2.COLOR_BGR2RGB)
        transposed_image = np.transpose(rgb_image, (2, 0, 1))
        input_tensor = np.ascontiguousarray(transposed_image, dtype=np.float32) / 255.0
        input_tensor = np.expand_dims(input_tensor, axis=0)
        return input_tensor, ratio, (dw, dh), original_width, original_height

    def _postprocess(self, outputs, ratio, padding_dw_dh, original_width, original_height, confidence_threshold, iou_threshold):
        if ratio == 0:
             return [], [], []
        predictions = outputs[0]
        if predictions.shape[1] < predictions.shape[2] and \
           (predictions.shape[1] == (len(self.class_names) + 4) or predictions.shape[1] > 10):
            predictions = np.transpose(predictions, (0, 2, 1))

        output_data = predictions[0]
        boxes, scores, class_ids = [], [], []
        pad_w, pad_h = padding_dw_dh

        for i in range(output_data.shape[0]):
            detection = output_data[i]
            cx, cy, w, h = detection[:4]
            class_confidences = detection[4:]
            if len(self.class_names) == 1:
                object_confidence = class_confidences[0]
                class_id = 0
            else:
                object_confidence = np.max(class_confidences)
                class_id = np.argmax(class_confidences)

            if object_confidence >= confidence_threshold:
                x1_letterboxed = cx - w / 2
                y1_letterboxed = cy - h / 2
                w_model = w; h_model = h
                x1_original = (x1_letterboxed - pad_w) / ratio
                y1_original = (y1_letterboxed - pad_h) / ratio
                w_original = w_model / ratio
                h_original = h_model / ratio
                x1_final = np.clip(x1_original, 0, original_width)
                y1_final = np.clip(y1_original, 0, original_height)
                x2_final = np.clip(x1_original + w_original, 0, original_width)
                y2_final = np.clip(y1_original + h_original, 0, original_height)
                final_w = x2_final - x1_final
                final_h = y2_final - y1_final
                if final_w > 0 and final_h > 0:
                    boxes.append([int(x1_final), int(y1_final), int(final_w), int(final_h)])
                    scores.append(float(object_confidence))
                    class_ids.append(int(class_id))
        if boxes:
            indices = cv2.dnn.NMSBoxes(boxes, scores, confidence_threshold, iou_threshold)
            if len(indices) > 0:
                indices = indices.flatten()
                return [boxes[i] for i in indices], [scores[i] for i in indices], [class_ids[i] for i in indices]
        return [], [], []

    def detect(self, image_bgr, confidence_thresh, iou_thresh):
        input_tensor, ratio, padding_dw_dh, ow, oh = self._preprocess(image_bgr)
        if input_tensor is None: return [], [], []
        outputs = self.session.run(self.output_names, {self.input_name: input_tensor})
        return self._postprocess(outputs, ratio, padding_dw_dh, ow, oh, confidence_thresh, iou_thresh)

def detection_thread_func():
    global latest_detections, detector_instance, current_iou_threshold, current_detection_interval
    global screen_width, screen_height, current_fov_size
    global aimbot_active_var, aimbot_target_part_var
    global aimbot_key_lmb_var, aimbot_key_rmb_var
    global continuous_detection_var
    global inference_device_var

    AIMBOT_MOVE_INTERVAL = 1.0 / 26.0  # 最多每秒26次
    last_aimbot_move_time = 0.0

    sct = mss.mss()
    monitor_definition = sct.monitors[1]
    if detector_instance is None:
        try:
            device = inference_device_var.get() if inference_device_var else 'GPU'
            detector_instance = RivalDetectorYOLO(MODEL_FILE, device=device)
        except Exception as e:
            print(f"初始化偵測器失敗: {e}")
            return

    last_detection_time = time.perf_counter()

    while True:
        # 新增：支援持續檢測模式
        aim_key_pressed = False
        if continuous_detection_var is not None and continuous_detection_var.get():
            aim_key_pressed = True
            aimbot_should_move = (aimbot_key_lmb_var is not None and aimbot_key_lmb_var.get() and is_key_pressed(VK_LBUTTON)) or \
                                (aimbot_key_rmb_var is not None and aimbot_key_rmb_var.get() and is_key_pressed(VK_RBUTTON))
        else:
            if aimbot_key_lmb_var is not None and aimbot_key_lmb_var.get() and is_key_pressed(VK_LBUTTON):
                aim_key_pressed = True
            if aimbot_key_rmb_var is not None and aimbot_key_rmb_var.get() and is_key_pressed(VK_RBUTTON):
                aim_key_pressed = True
            aimbot_should_move = aim_key_pressed  # 只有有按鍵時才自瞄

        if not is_detection_running.is_set() or not aim_key_pressed:
            if latest_detections: latest_detections = []
            time.sleep(0.06); last_detection_time = time.perf_counter(); continue

        current_time = time.perf_counter()
        perform_detection_now = (current_detection_interval == 0.0) or \
                                (current_time - last_detection_time >= current_detection_interval)
        if perform_detection_now:
            last_detection_time = current_time
            try:
                sct_img = sct.grab(monitor_definition)
                frame_bgr_full = cv2.cvtColor(np.array(sct_img), cv2.COLOR_BGRA2BGR)
                fov_s = current_fov_size.get()
                fov_x = int((screen_width - fov_s) / 2); fov_y = int((screen_height - fov_s) / 2)
                fov_x = max(0, fov_x); fov_y = max(0, fov_y)
                fov_x_end = min(screen_width, fov_x + fov_s); fov_y_end = min(screen_height, fov_y + fov_s)
                if fov_x_end <= fov_x or fov_y_end <= fov_y: latest_detections = []; continue
                frame_bgr_fov = frame_bgr_full[fov_y:fov_y_end, fov_x:fov_x_end]
                if frame_bgr_fov.shape[0] == 0 or frame_bgr_fov.shape[1] == 0: latest_detections = []; continue
                boxes_fov, scores, class_ids = detector_instance.detect(
                    frame_bgr_fov, current_confidence_threshold, current_iou_threshold
                )
                latest_detections = [{"box": [x_f + fov_x, y_f + fov_y, w_f, h_f],
                                      "score": scores[i], "class_name": detector_instance.class_names[class_ids[i]]}
                                     for i, (x_f, y_f, w_f, h_f) in enumerate(boxes_fov)]
            except Exception as e:
                print(f"偵測迴圈錯誤: {e}"); time.sleep(0.06)

        # Aimbot 移動（加上速率限制）
        if aimbot_active_var is not None and aimbot_active_var.get() and aim_key_pressed and latest_detections and aimbot_should_move:
            now = time.perf_counter()
            if now - last_aimbot_move_time >= AIMBOT_MOVE_INTERVAL:
                last_aimbot_move_time = now
                fov_center_x_screen = screen_width / 2; fov_center_y_screen = screen_height / 2
                closest_enemy_data = None; min_dist_sq = float('inf')
                for det in latest_detections:
                    box_x, box_y, box_w, box_h = det["box"]
                    enemy_center_x = box_x + box_w / 2; enemy_center_y = box_y + box_h / 2
                    dist_sq = (enemy_center_x - fov_center_x_screen)**2 + (enemy_center_y - fov_center_y_screen)**2
                    if dist_sq < min_dist_sq: min_dist_sq = dist_sq; closest_enemy_data = det
                if closest_enemy_data:
                    box_x, box_y, box_w, box_h = closest_enemy_data["box"]
                    target_part_str = aimbot_target_part_var.get()
                    target_x_abs = box_x + box_w / 2
                    target_y_abs = (box_y + box_h / 6) if target_part_str == "Head" else (box_y + box_h / 2)
                    pt = ctypes.wintypes.POINT()
                    ctypes.windll.user32.GetCursorPos(ctypes.byref(pt))
                    delta_x = target_x_abs - pt.x; delta_y = target_y_abs - pt.y
                    if abs(delta_x) > 0.5 or abs(delta_y) > 0.5: # 避免目標已小時的抖動
                        move_mouse_relative(int(round(delta_x)), int(round(delta_y)))
        if not perform_detection_now:
            time.sleep(0.01)

def update_overlay_canvas_func():
    global overlay_canvas, overlay_window, show_confidence_text, confidence_font_size
    global show_head_point, show_body_point, current_x_offset, current_y_offset
    global screen_width, screen_height, current_fov_size, current_fov_thickness, default_font

    if overlay_canvas:
        overlay_canvas.delete("all")
        offset_x = current_x_offset.get() if current_x_offset else 0
        offset_y = current_y_offset.get() if current_y_offset else 0
        fov_s_draw = current_fov_size.get() if current_fov_size else INITIAL_FOV_SIZE
        fov_thick_draw = current_fov_thickness.get() if current_fov_thickness else INITIAL_FOV_THICKNESS
        fov_draw_x1 = (screen_width - fov_s_draw) / 2 + offset_x
        fov_draw_y1 = (screen_height - fov_s_draw) / 2 + offset_y
        fov_draw_x2 = fov_draw_x1 + fov_s_draw; fov_draw_y2 = fov_draw_y1 + fov_s_draw
        overlay_canvas.create_rectangle(fov_draw_x1, fov_draw_y1, fov_draw_x2, fov_draw_y2,
                                        outline="white", width=fov_thick_draw)
        if is_detection_running.is_set():
            for det in latest_detections:
                orig_x, orig_y, orig_w, orig_h = det["box"]
                score = det["score"]; class_name = det["class_name"]
                draw_x = orig_x + offset_x; draw_y = orig_y + offset_y
                draw_x2 = draw_x + orig_w; draw_y2 = draw_y + orig_h
                overlay_canvas.create_rectangle(draw_x, draw_y, draw_x2, draw_y2, outline="lime green", width=2)
                if show_confidence_text is not None and show_confidence_text.get():
                    font_val = confidence_font_size.get() if confidence_font_size else 9
                    font_family = default_font.actual()['family'] if default_font else "TkDefaultFont"
                    text_y = draw_y - (font_val + 3) if draw_y > (font_val + 3) else draw_y + orig_h + 2
                    overlay_canvas.create_text(draw_x, text_y, text=f"{class_name}: {score:.2f}",
                                               fill="lime green", anchor="nw", font=(font_family, font_val, "bold"))
                if show_head_point is not None and show_head_point.get():
                    hx = orig_x + orig_w / 2 + offset_x; hy = orig_y + orig_h / 6 + offset_y
                    overlay_canvas.create_oval(hx - POINT_RADIUS, hy - POINT_RADIUS, hx + POINT_RADIUS, hy + POINT_RADIUS,
                                               fill="red", outline="red")
                if show_body_point is not None and show_body_point.get():
                    bx = orig_x + orig_w / 2 + offset_x; by = orig_y + orig_h / 2 + offset_y
                    overlay_canvas.create_oval(bx - POINT_RADIUS, by - POINT_RADIUS, bx + POINT_RADIUS, by + POINT_RADIUS,
                                               fill="blue", outline="blue")
    if overlay_window:
        overlay_window.after(OVERLAY_UPDATE_INTERVAL_MS, update_overlay_canvas_func)

# --- GUI Callbacks ---
def toggle_detection(): global is_detection_running; is_detection_running.set() if not is_detection_running.is_set() else is_detection_running.clear(); toggle_button.config(text="停止偵測" if is_detection_running.is_set() else "開始偵測")
def on_confidence_change(val): global current_confidence_threshold; current_confidence_threshold = float(val); conf_value_label.config(text=f"{current_confidence_threshold:.2f}")
def on_iou_change(val): global current_iou_threshold; current_iou_threshold = float(val); iou_value_label.config(text=f"{current_iou_threshold:.2f}")
def on_font_size_change(val): font_size_value_label.config(text=f"{int(float(val))}")
def on_detection_interval_change(val): global current_detection_interval; current_detection_interval = float(val); interval_value_label.config(text=f"{current_detection_interval:.3f}s")
def on_offset_change(axis, val):
    global x_offset_value_label, y_offset_value_label
    value = int(float(val))
    if axis == 'x':
        if 'x_offset_value_label' in globals() and x_offset_value_label:
            x_offset_value_label.config(text=f"{value}")
    else:
        if 'y_offset_value_label' in globals() and y_offset_value_label:
            y_offset_value_label.config(text=f"{value}")
def on_fov_size_change(val): fov_size_value_label.config(text=f"{int(float(val))}")
def on_fov_thickness_change(val): fov_thickness_value_label.config(text=f"{int(float(val))}")

def on_closing_main_window():
    global root, overlay_window
    is_detection_running.clear()
    if aimbot_active_var: aimbot_active_var.set(False)
    if overlay_window:
        try: overlay_window.destroy()
        except tk.TclError: pass
        overlay_window = None
    if root:
        try: root.destroy()
        except tk.TclError: pass
        root = None
    print("應用程式請求關閉...")

if __name__ == "__main__":
    # screen_width = win32api.GetSystemMetrics(win32con.SM_CXSCREEN) # 使用 win32api 獲取
    # screen_height = win32api.GetSystemMetrics(win32con.SM_CYSCREEN) # 使用 win32api 獲取
    # 註解掉上面兩行，因為 mss.mss().monitors[1] 也能提供螢幕資訊，且更通用於多螢幕主螢幕
    sct_for_screen_info = mss.mss()
    monitor_info = sct_for_screen_info.monitors[1] # 通常 monitors[0] 是整個虛擬桌面, monitors[1] 是主螢幕
    screen_width = monitor_info["width"]
    screen_height = monitor_info["height"]
    del sct_for_screen_info





    root = tk.Tk(); root.title("niggaLOSE AI"); root.geometry("500x500"); root.attributes('-topmost', True)
    try:
        from PIL import Image, ImageTk
        icon_img = Image.open(resource_path("logo.png"))
        icon_tk = ImageTk.PhotoImage(icon_img)
        root.iconphoto(True, icon_tk)
    except Exception as e:
        print(f"設定視窗圖標失敗: {e}")


    default_font = tkFont.nametofont("TkDefaultFont")

    show_confidence_text = tk.BooleanVar(value=INITIAL_SHOW_CONFIDENCE_TEXT)
    confidence_font_size = tk.IntVar(value=INITIAL_CONFIDENCE_FONT_SIZE)
    show_head_point = tk.BooleanVar(value=INITIAL_SHOW_HEAD_POINT)
    show_body_point = tk.BooleanVar(value=INITIAL_SHOW_BODY_POINT)
    current_x_offset = tk.IntVar(value=INITIAL_X_OFFSET)
    current_y_offset = tk.IntVar(value=INITIAL_Y_OFFSET)
    current_fov_size = tk.IntVar(value=INITIAL_FOV_SIZE)
    current_fov_thickness = tk.IntVar(value=INITIAL_FOV_THICKNESS)
    aimbot_active_var = tk.BooleanVar(value=INITIAL_AIMBOT_ACTIVE)
    aimbot_target_part_var = tk.StringVar(value=INITIAL_AIMBOT_TARGET_PART)
    aimbot_key_lmb_var = tk.BooleanVar(value=INITIAL_AIMBOT_KEY_LMB)
    aimbot_key_rmb_var = tk.BooleanVar(value=INITIAL_AIMBOT_KEY_RMB)
    
    # 新增：Aimbot 速度變數
    aimbot_speed_var = tk.DoubleVar(value=1.0)

    # --- 紅色主題 Style 設定 ---
    style = ttk.Style()
    style.theme_use('clam')
    # 主背景與分區
    style.configure("HopzRed.TFrame", background="#18141c")
    style.configure("HopzRed.TLabelframe", background="#18141c", foreground="#ff3b3b", font=("Segoe UI", 13, "bold"), borderwidth=0, relief="flat")
    style.configure("HopzRed.TLabelframe.Label", background="#18141c", foreground="#ff3b3b", font=("Segoe UI", 13, "bold"))
    # 標籤
    style.configure("HopzRed.TLabel", background="#18141c", foreground="#ff3b3b", font=("Segoe UI", 12, "bold"))
    # 按鈕
    style.configure("HopzRed.TButton", background="#ff3b3b", foreground="#fff", font=("Segoe UI", 12, "bold"), borderwidth=0, relief="flat", padding=8)
    style.map("HopzRed.TButton", background=[('active', '#b71c1c')], foreground=[('active', '#fff')])
    # 勾選框
    style.configure("HopzRed.TCheckbutton", background="#18141c", foreground="#ff3b3b", font=("Segoe UI", 11, "bold"), focuscolor="#ff3b3b")
    # 下拉選單
    style.configure("HopzRed.TCombobox", fieldbackground="#fff0f0", background="#fff0f0", foreground="#b71c1c", selectbackground="#ff3b3b", selectforeground="#fff")
    # 滑桿
    style.configure("HopzRed.Horizontal.TScale", troughcolor="#ffb3b3", background="#ff3b3b")

    # --- 主 Frame ---
    main_frame = ttk.Frame(root, padding="24 18 24 18", style="HopzRed.TFrame"); main_frame.pack(expand=True, fill=tk.BOTH)

    # --- LOGO 與標題 ---
    try:
        from PIL import Image, ImageTk
        logo_img = Image.open(resource_path("logo.png"))
        logo_img = logo_img.resize((90, 90), Image.LANCZOS)
        logo_tk = ImageTk.PhotoImage(logo_img)
        logo_label = ttk.Label(main_frame, image=logo_tk, style="HopzRed.TLabel")
        logo_label.image = logo_tk
        main_frame.logo_tk = logo_tk  # 防止被GC
        logo_label.pack(pady=(0, 5))
    except Exception as e:
        print(f"載入logo失敗: {e}")
        logo_label = ttk.Label(main_frame, text=" ", style="HopzRed.TLabel", font=("Segoe UI", 32, "bold"))
        logo_label.pack(pady=(0, 5))
    title_label = ttk.Label(main_frame, text="niggaLOSE AI", style="HopzRed.TLabel", font=("Segoe UI", 18, "bold"))
    title_label.pack(pady=(0, 18))

    # --- 分頁 Notebook ---
    notebook = ttk.Notebook(main_frame)
    notebook.pack(expand=True, fill=tk.BOTH)

    # --- 分頁: 偵測控制 ---
    tab_control = ttk.Frame(notebook, style="HopzRed.TFrame")
    notebook.add(tab_control, text="偵測控制")
    toggle_button = ttk.Button(tab_control, text="開始偵測", command=toggle_detection, width=22, style="HopzRed.TButton"); toggle_button.pack(pady=(10,8))
    continuous_detection_var = tk.BooleanVar(master=root, value=False)
    continuous_detection_cb = ttk.Checkbutton(tab_control, text="持續檢測模式 (不需按鍵)", variable=continuous_detection_var, style="HopzRed.TCheckbutton")
    continuous_detection_cb.pack(anchor="w", pady=(0, 2))

    # --- 分頁: 偵測參數 ---
    tab_param = ttk.Frame(notebook, style="HopzRed.TFrame")
    notebook.add(tab_param, text="偵測參數")
    conf_row = ttk.Frame(tab_param, style="HopzRed.TFrame"); conf_row.pack(fill='x', pady=8)
    ttk.Label(conf_row, text="信心值:", style="HopzRed.TLabel").pack(side=tk.LEFT)
    conf_slider = ttk.Scale(conf_row, from_=0.01, to=1.0, value=INITIAL_CONFIDENCE_THRESHOLD, orient=tk.HORIZONTAL, command=on_confidence_change, length=180, style="HopzRed.Horizontal.TScale"); conf_slider.pack(side=tk.LEFT, padx=8)
    conf_value_label = ttk.Label(conf_row, text=f"{INITIAL_CONFIDENCE_THRESHOLD:.2f}", width=4, style="HopzRed.TLabel"); conf_value_label.pack(side=tk.LEFT)
    iou_row = ttk.Frame(tab_param, style="HopzRed.TFrame"); iou_row.pack(fill='x', pady=8)
    ttk.Label(iou_row, text="IoU 閾值:", style="HopzRed.TLabel").pack(side=tk.LEFT)
    iou_slider = ttk.Scale(iou_row, from_=0.01, to=1.0, value=INITIAL_IOU_THRESHOLD, orient=tk.HORIZONTAL, command=on_iou_change, length=180, style="HopzRed.Horizontal.TScale"); iou_slider.pack(side=tk.LEFT, padx=8)
    iou_value_label = ttk.Label(iou_row, text=f"{INITIAL_IOU_THRESHOLD:.2f}", width=4, style="HopzRed.TLabel"); iou_value_label.pack(side=tk.LEFT)
    interval_row = ttk.Frame(tab_param, style="HopzRed.TFrame"); interval_row.pack(fill='x', pady=8)
    ttk.Label(interval_row, text="檢測間隔(秒):", style="HopzRed.TLabel").pack(side=tk.LEFT)
    interval_slider = ttk.Scale(interval_row, from_=0.0, to=1.0, value=INITIAL_DETECTION_INTERVAL, orient=tk.HORIZONTAL, command=on_detection_interval_change, length=180, style="HopzRed.Horizontal.TScale"); interval_slider.pack(side=tk.LEFT, padx=8)
    interval_value_label = ttk.Label(interval_row, text=f"{INITIAL_DETECTION_INTERVAL:.3f}s", width=6, style="HopzRed.TLabel"); interval_value_label.pack(side=tk.LEFT)

    # --- 分頁: FOV 設定 ---
    tab_fov = ttk.Frame(notebook, style="HopzRed.TFrame")
    notebook.add(tab_fov, text="FOV 設定")
    fov_size_row = ttk.Frame(tab_fov, style="HopzRed.TFrame"); fov_size_row.pack(fill='x', pady=8)
    ttk.Label(fov_size_row, text="大小 (像素):", style="HopzRed.TLabel").pack(side=tk.LEFT)
    fov_size_slider = ttk.Scale(fov_size_row, from_=50, to=max(1024, screen_width, screen_height), variable=current_fov_size, orient=tk.HORIZONTAL, command=on_fov_size_change, length=180, style="HopzRed.Horizontal.TScale"); fov_size_slider.pack(side=tk.LEFT, padx=8)
    fov_size_value_label = ttk.Label(fov_size_row, text=f"{INITIAL_FOV_SIZE}", width=4, style="HopzRed.TLabel"); fov_size_value_label.pack(side=tk.LEFT)
    fov_thick_row = ttk.Frame(tab_fov, style="HopzRed.TFrame"); fov_thick_row.pack(fill='x', pady=8)
    ttk.Label(fov_thick_row, text="框線粗細:", style="HopzRed.TLabel").pack(side=tk.LEFT)
    fov_thick_slider = ttk.Scale(fov_thick_row, from_=1, to=10, variable=current_fov_thickness, orient=tk.HORIZONTAL, command=on_fov_thickness_change, length=180, style="HopzRed.Horizontal.TScale"); fov_thick_slider.pack(side=tk.LEFT, padx=8)
    fov_thickness_value_label = ttk.Label(fov_thick_row, text=f"{INITIAL_FOV_THICKNESS}", width=3, style="HopzRed.TLabel"); fov_thickness_value_label.pack(side=tk.LEFT)

    # --- 分頁: Aimbot 設定 ---
    tab_aimbot = ttk.Frame(notebook, style="HopzRed.TFrame")
    notebook.add(tab_aimbot, text="Aimbot 設定")
    aimbot_active_cb = ttk.Checkbutton(tab_aimbot, text="啟用 Aimbot", variable=aimbot_active_var, style="HopzRed.TCheckbutton"); aimbot_active_cb.pack(anchor="w", pady=8)
    aim_keys_row = ttk.Frame(tab_aimbot, style="HopzRed.TFrame"); aim_keys_row.pack(fill="x", pady=8)
    ttk.Label(aim_keys_row, text="瞄準按鍵:", style="HopzRed.TLabel").pack(side=tk.LEFT)
    aim_lmb_cb = ttk.Checkbutton(aim_keys_row, text="左鍵", variable=aimbot_key_lmb_var, style="HopzRed.TCheckbutton"); aim_lmb_cb.pack(side=tk.LEFT, padx=5)
    aim_rmb_cb = ttk.Checkbutton(aim_keys_row, text="右鍵", variable=aimbot_key_rmb_var, style="HopzRed.TCheckbutton"); aim_rmb_cb.pack(side=tk.LEFT, padx=5)
    target_part_row = ttk.Frame(tab_aimbot, style="HopzRed.TFrame"); target_part_row.pack(fill="x", pady=8)
    ttk.Label(target_part_row, text="瞄準部位:", style="HopzRed.TLabel").pack(side=tk.LEFT)
    target_part_combo = ttk.Combobox(target_part_row, textvariable=aimbot_target_part_var, values=["Head", "Body"], width=8, state="readonly", style="HopzRed.TCombobox"); target_part_combo.pack(side=tk.LEFT, padx=5); target_part_combo.set(INITIAL_AIMBOT_TARGET_PART)
    speed_row = ttk.Frame(tab_aimbot, style="HopzRed.TFrame"); speed_row.pack(fill="x", pady=8)
    ttk.Label(speed_row, text="速度:", style="HopzRed.TLabel").pack(side=tk.LEFT)
    speed_slider = ttk.Scale(speed_row, from_=0.1, to=5.0, variable=aimbot_speed_var, orient=tk.HORIZONTAL, length=120, command=lambda v: speed_value_label.config(text=f"{float(v):.2f}"), style="HopzRed.Horizontal.TScale")
    speed_slider.pack(side=tk.LEFT, padx=8)
    speed_slider.set(1.0)
    speed_value_label = ttk.Label(speed_row, text="1.00", width=5, style="HopzRed.TLabel")
    speed_value_label.pack(side=tk.LEFT)

    # --- 分頁: ESP 設定 ---
    tab_display = ttk.Frame(notebook, style="HopzRed.TFrame")
    notebook.add(tab_display, text="ESP 設定")
    text_row = ttk.Frame(tab_display, style="HopzRed.TFrame"); text_row.pack(fill='x', pady=8)
    show_conf_check = ttk.Checkbutton(text_row, text="顯示可信度", variable=show_confidence_text, style="HopzRed.TCheckbutton"); show_conf_check.pack(side=tk.LEFT, padx=5)
    ttk.Label(text_row, text="字型大小:", style="HopzRed.TLabel").pack(side=tk.LEFT, padx=(10,0))
    font_size_slider = ttk.Scale(text_row, from_=6, to=24, variable=confidence_font_size, orient=tk.HORIZONTAL, command=on_font_size_change, length=100, style="HopzRed.Horizontal.TScale"); font_size_slider.pack(side=tk.LEFT, padx=5); font_size_slider.set(INITIAL_CONFIDENCE_FONT_SIZE)
    font_size_value_label = ttk.Label(text_row, text=f"{INITIAL_CONFIDENCE_FONT_SIZE}", width=3, style="HopzRed.TLabel"); font_size_value_label.pack(side=tk.LEFT)
    point_row = ttk.Frame(tab_display, style="HopzRed.TFrame"); point_row.pack(fill='x', pady=8)
    show_head_cb = ttk.Checkbutton(point_row, text="頭部點 (紅)", variable=show_head_point, style="HopzRed.TCheckbutton"); show_head_cb.pack(side=tk.LEFT, padx=5)
    show_body_cb = ttk.Checkbutton(point_row, text="身體點 (藍)", variable=show_body_point, style="HopzRed.TCheckbutton"); show_body_cb.pack(side=tk.LEFT, padx=5)

    # --- 分頁: 推論設備 ---
    tab_device = ttk.Frame(notebook, style="HopzRed.TFrame")
    notebook.add(tab_device, text="推論設備")
    device_combo = ttk.Combobox(tab_device, textvariable=inference_device_var, values=["GPU", "CPU"], width=8, state="readonly", style="HopzRed.TCombobox")
    device_combo.pack(side=tk.LEFT, padx=5, pady=10)
    device_combo.set("GPU")
    ttk.Label(tab_device, text="(GPU=DirectML，不會自動退回CPU)", style="HopzRed.TLabel").pack(side=tk.LEFT, padx=5, pady=10)

    # --- 底部提示 ---
    ttk.Label(main_frame, text="關閉此視窗即可結束 HopzAI。", font=("Segoe UI", 10, "bold"), style="HopzRed.TLabel").pack(pady=(16,0), side=tk.BOTTOM)
    root.protocol("WM_DELETE_WINDOW", on_closing_main_window)

    # --- Overlay Window Setup ---
    overlay_window = tk.Toplevel(root)
    overlay_window.title("ESPOverlay") # 標題不會顯示，但有助於調試
    overlay_window.geometry(f"{screen_width}x{screen_height}+0+0") # 全螢幕
    overlay_window.attributes('-topmost', True) # 保持在最上層
    overlay_window.overrideredirect(True) # 建立無邊框視窗

    # 獲取視窗句柄 (HWND)
    # 需要在視窗真正顯示後才能獲取，但 overrideredirect 後立即獲取通常可行
    # 為了更穩定，可以 overlay_window.update_idletasks() 一下
    overlay_window.update_idletasks()
    hwnd = win32gui.FindWindow(None, "ESPOverlay") # 或者使用 overlay_window.winfo_id() 轉換
    if not hwnd: # 如果 FindWindow 失敗，嘗試用 Tkinter 的方法獲取並轉換
        try:
            # 有時 .winfo_id() 返回的是字串形式的 ID，需要轉換
            hwnd_str = overlay_window.winfo_id()
            hwnd = int(hwnd_str) # 如果 winfo_id() 返回的是整數，這步也是安全的
            print(f"成功獲取 HWND: {hwnd} (透過 winfo_id)")
        except Exception as e:
            print(f"獲取 HWND 失敗: {e}")
            hwnd = None # 確保 hwnd 在失敗時是 None

    if hwnd:
        # 1. 設定 WS_EX_LAYERED: 允許視窗分層，是透明的基礎
        current_ex_style = win32gui.GetWindowLong(hwnd, win32con.GWL_EXSTYLE)
        win32gui.SetWindowLong(hwnd, win32con.GWL_EXSTYLE, current_ex_style | win32con.WS_EX_LAYERED)
        print("已設定 WS_EX_LAYERED")

        # 2. 設定視覺透明 (使用 Tkinter 的 transparentcolor，它會調用 SetLayeredWindowAttributes)
        transparent_color = '#abcdef' # 選擇一個不太可能在繪圖中使用的顏色
        overlay_window.attributes('-transparentcolor', transparent_color)
        overlay_window.configure(bg=transparent_color) # 設定視窗背景為此透明色
        print(f"已設定 transparentcolor: {transparent_color}")

        # 3. 設定 WS_EX_TRANSPARENT: 使滑鼠事件穿透視窗
        # 確保在 WS_EX_LAYERED 和透明色鍵設定之後
        current_ex_style = win32gui.GetWindowLong(hwnd, win32con.GWL_EXSTYLE)
        win32gui.SetWindowLong(hwnd, win32con.GWL_EXSTYLE, current_ex_style | win32con.WS_EX_TRANSPARENT)
        print("已設定 WS_EX_TRANSPARENT (滑鼠穿透)")
    else:
        print("錯誤：未能獲取疊加視窗的 HWND，無法設定滑鼠穿透。疊加層可能無法正常工作。")
        # 這裡可以選擇是否要退出，或者讓程式繼續運行但疊加層可能無法點擊穿透
        # 為了測試，我們先讓它繼續

    overlay_canvas = tk.Canvas(overlay_window, bg=transparent_color, highlightthickness=0)
    overlay_canvas.pack(fill=tk.BOTH, expand=True)
    detection_th = threading.Thread(target=detection_thread_func, daemon=True); detection_th.start()
    update_overlay_canvas_func()
    root.mainloop()
    is_detection_running.clear()
    print("應用程式已關閉。")